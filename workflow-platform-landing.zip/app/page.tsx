"use client"

import { useState } from "react"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { EnterpriseSidebar } from "@/components/enterprise-sidebar"
import { EnterpriseDashboard } from "@/components/enterprise-dashboard"
import { MobilePreview } from "@/components/mobile-preview"
import { CodeEditor } from "@/components/code-editor"
import { IntegrationsPanel } from "@/components/integrations-panel"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Lock, CheckCircle, Download, Play, Smartphone } from "lucide-react"
import { DesignWorkspace } from "@/components/design-workspace"
import { ClientReviewPage } from "@/components/client-review-page"
import { AIPreferences } from "@/components/ai-preferences"
import { ThemeProvider } from "@/components/theme-provider"
import { EnhancedProjectBrief } from "@/components/enhanced-project-brief" // Import EnhancedProjectBrief
import { ArchitectureAnalyzer } from "@/components/architecture-analyzer"

function WorkflowPlatformContent() {
  const [currentPath, setCurrentPath] = useState("/")
  const [sidebarOpen, setSidebarOpen] = useState(true)

  // Handle navigation and auto-hide sidebar for code editor
  const handleNavigate = (path: string) => {
    setCurrentPath(path)
    // Auto-hide sidebar when entering code editor, but allow manual control
    if (path === "/code" && sidebarOpen) {
      setSidebarOpen(false)
    }
    // Auto-show sidebar when leaving code editor (if it was hidden)
    if (path !== "/code" && currentPath === "/code" && !sidebarOpen) {
      setSidebarOpen(true)
    }
  }

  // Rest of the existing state remains the same...
  const [projectData, setProjectData] = useState({
    name: "E-commerce App",
    brief: "A modern e-commerce mobile app with product catalog, shopping cart, and payment integration.",
    primaryColor: "#2563eb",
    logo: null as File | null,
  })

  const [screens, setScreens] = useState([
    {
      id: "home",
      name: "Home",
      image: "/placeholder.svg?height=640&width=320&text=Home+Screen",
      comments: [
        {
          id: "1",
          x: 50,
          y: 30,
          text: "Can we make this header bigger?",
          author: "Client",
          timestamp: "2 hours ago",
        },
      ],
    },
    {
      id: "product",
      name: "Product",
      image: "/placeholder.svg?height=640&width=320&text=Product+Screen",
      comments: [],
    },
    {
      id: "cart",
      name: "Cart",
      image: "/placeholder.svg?height=640&width=320&text=Cart+Screen",
      comments: [
        {
          id: "2",
          x: 70,
          y: 60,
          text: "Add quantity selector here",
          author: "Client",
          timestamp: "1 hour ago",
        },
        {
          id: "3",
          x: 30,
          y: 80,
          text: "Remove button should be red",
          author: "Client",
          timestamp: "30 minutes ago",
        },
      ],
    },
  ])

  const [currentScreen, setCurrentScreen] = useState(0)
  const [isApproved, setIsApproved] = useState(false)
  // Add new state for architecture
  const [architectureData, setArchitectureData] = useState(null)

  const addComment = (screenId: string, x: number, y: number, text: string) => {
    const newComment = {
      id: Date.now().toString(),
      x,
      y,
      text,
      author: "Client",
      timestamp: "Just now",
    }

    setScreens((prev) =>
      prev.map((screen) =>
        screen.id === screenId ? { ...screen, comments: [...screen.comments, newComment] } : screen,
      ),
    )
  }

  const generateAIDesign = () => {
    // Simulate AI generation
    setTimeout(() => {
      handleNavigate("/design")
    }, 1000)
  }

  // Update the generateAIDesign function
  const generateAIArchitecture = () => {
    // Simulate AI generation
    setTimeout(() => {
      handleNavigate("/architecture")
    }, 1000)
  }

  const renderContent = () => {
    switch (currentPath) {
      case "/":
        return <EnterpriseDashboard onProjectSelect={(id) => console.log("Selected project:", id)} />

      // Update the brief case to use the new function
      case "/brief":
        return <EnhancedProjectBrief onGenerateArchitecture={generateAIArchitecture} />

      case "/design":
        return (
          <DesignWorkspace
            screens={screens}
            currentScreen={currentScreen}
            onScreenChange={setCurrentScreen}
            onAddComment={addComment}
            onScreensUpdate={setScreens}
          />
        )

      case "/review":
        return (
          <ClientReviewPage
            screens={screens}
            currentScreen={currentScreen}
            onScreenChange={setCurrentScreen}
            onAddComment={addComment}
            onNavigate={handleNavigate}
          />
        )

      case "/approve":
        return (
          <div className="min-h-screen bg-gray-50">
            <div className="bg-white border-b border-gray-200 px-6 py-4">
              <h1 className="text-2xl font-semibold text-gray-900">Design Approval</h1>
              <p className="text-sm text-gray-600 mt-1">Review and approve final design before development</p>
            </div>

            <div className="p-6 max-w-2xl mx-auto">
              <Card className="border-0 shadow-sm mb-6">
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-gray-900">Design Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Screens:</span>
                      <span className="font-medium text-gray-900">{screens.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Comments Resolved:</span>
                      <span className="font-medium text-gray-900">3/3</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Revisions Made:</span>
                      <span className="font-medium text-gray-900">2</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {!isApproved ? (
                <div className="text-center space-y-4">
                  <p className="text-gray-600">
                    Once approved, this design version will be locked and development can begin.
                  </p>
                  <Button
                    size="lg"
                    onClick={() => {
                      setIsApproved(true)
                      setTimeout(() => handleNavigate("/code"), 1000)
                    }}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Lock className="w-4 h-4 mr-2" />
                    Approve & Lock Design
                  </Button>
                </div>
              ) : (
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-green-600">Design Approved!</h3>
                  <p className="text-gray-600">
                    The design is now locked. Generating code and setting up repository...
                  </p>
                </div>
              )}
            </div>
          </div>
        )

      case "/code":
        return <CodeEditor />

      case "/preview":
        return (
          <div className="min-h-screen bg-gray-50">
            <div className="bg-white border-b border-gray-200 px-6 py-4">
              <h1 className="text-2xl font-semibold text-gray-900">Live Preview</h1>
              <p className="text-sm text-gray-600 mt-1">Test your application in real-time</p>
            </div>

            <div className="p-6 flex justify-center">
              <div className="flex space-x-8">
                <MobilePreview
                  screens={screens}
                  currentScreen={currentScreen}
                  onScreenChange={setCurrentScreen}
                  onAddComment={addComment}
                />
                <div className="w-80">
                  <Card className="border-0 shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-lg font-semibold text-gray-900">Preview Controls</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <Button className="w-full bg-blue-600 hover:bg-blue-700">
                        <Play className="w-4 h-4 mr-2" />
                        Refresh Preview
                      </Button>
                      <Button variant="outline" className="w-full bg-transparent">
                        <Smartphone className="w-4 h-4 mr-2" />
                        Open on Device
                      </Button>
                      <Button variant="outline" className="w-full bg-transparent">
                        <Download className="w-4 h-4 mr-2" />
                        Generate QR Code
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        )

      case "/integrations":
        return <IntegrationsPanel />

      case "/ai-preferences":
        return <AIPreferences />

      // Add architecture case in renderContent switch statement
      case "/architecture":
        return (
          <ArchitectureAnalyzer
            projectBrief={projectData.brief}
            onArchitectureComplete={(analysis) => setArchitectureData(analysis)}
            onProceedToDesign={() => handleNavigate("/design")}
          />
        )

      default:
        return (
          <div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-2xl font-semibold text-gray-900 mb-2">Page Not Found</h1>
              <p className="text-gray-600">The requested page could not be found.</p>
            </div>
          </div>
        )
    }
  }

  return (
    <SidebarProvider open={sidebarOpen} onOpenChange={setSidebarOpen}>
      <EnterpriseSidebar currentPath={currentPath} onNavigate={handleNavigate} />
      <SidebarInset>
        <div className="h-screen overflow-auto">{renderContent()}</div>
      </SidebarInset>
    </SidebarProvider>
  )
}

export default function WorkflowPlatform() {
  return (
    <ThemeProvider>
      <WorkflowPlatformContent />
    </ThemeProvider>
  )
}
