"use client"
import {
  FileText,
  Smartphone,
  MessageSquare,
  Lock,
  Code,
  Play,
  Puzzle,
  Package,
  Clock,
  Settings,
  Home,
  Wand2,
} from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar"
import { Badge } from "@/components/ui/badge"
import { ThemeToggle } from "./theme-toggle"

const menuItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: Home,
  },
  {
    title: "Project Brief",
    url: "/brief",
    icon: FileText,
    badge: "1",
  },
  {
    title: "Design",
    url: "/design",
    icon: Smartphone,
    badge: "New",
  },
  {
    title: "Client Review",
    url: "/review",
    icon: MessageSquare,
    badge: "3",
  },
  {
    title: "Approve Design",
    url: "/approve",
    icon: Lock,
  },
  {
    title: "Code Editor",
    url: "/code",
    icon: Code,
  },
  {
    title: "Live Preview",
    url: "/preview",
    icon: Play,
  },
  {
    title: "Integrations",
    url: "/integrations",
    icon: Puzzle,
  },
  {
    title: "Build & Deploy",
    url: "/deploy",
    icon: Package,
  },
  {
    title: "Time & Billing",
    url: "/billing",
    icon: Clock,
  },
]

const settingsItems = [
  {
    title: "AI Preferences",
    url: "/ai-preferences",
    icon: Wand2,
    badge: "New",
  },
  {
    title: "Settings",
    url: "/settings",
    icon: Settings,
  },
]

interface AppSidebarProps {
  currentPath: string
  onNavigate: (path: string) => void
}

export function AppSidebar({ currentPath, onNavigate }: AppSidebarProps) {
  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <Code className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-semibold">WorkflowAI</h2>
              <p className="text-xs text-muted-foreground">E-commerce App</p>
            </div>
          </div>
          <ThemeToggle />
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Workflow</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={currentPath === item.url} onClick={() => onNavigate(item.url)}>
                    <button className="w-full flex items-center">
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                      {item.badge && (
                        <Badge variant={item.badge === "New" ? "default" : "secondary"} className="ml-auto text-xs">
                          {item.badge}
                        </Badge>
                      )}
                    </button>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Customization</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {settingsItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={currentPath === item.url} onClick={() => onNavigate(item.url)}>
                    <button className="w-full flex items-center">
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                      {item.badge && (
                        <Badge variant={item.badge === "New" ? "default" : "secondary"} className="ml-auto text-xs">
                          {item.badge}
                        </Badge>
                      )}
                    </button>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4">
        <div className="text-xs text-muted-foreground">
          <p>WorkflowAI v2.1.0</p>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
