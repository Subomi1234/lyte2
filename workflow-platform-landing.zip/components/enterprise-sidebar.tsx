"use client"

import {
  LayoutDashboard,
  FileText,
  Palette,
  MessageSquare,
  Shield,
  Code2,
  Monitor,
  Puzzle,
  Rocket,
  Clock,
  Settings,
  Wand2,
  Users,
  BarChart3,
} from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar"
import { Badge } from "@/components/ui/badge"
import { ThemeToggle } from "./theme-toggle"

const workflowItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Project Brief",
    url: "/brief",
    icon: FileText,
    badge: "1",
  },
  {
    title: "Architecture",
    url: "/architecture",
    icon: Code2,
    badge: "New",
  },
  {
    title: "Design Studio",
    url: "/design",
    icon: Palette,
  },
  {
    title: "Client Review",
    url: "/review",
    icon: MessageSquare,
    badge: "3",
  },
  {
    title: "Approval Gate",
    url: "/approve",
    icon: Shield,
  },
]

const developmentItems = [
  {
    title: "Code Editor",
    url: "/code",
    icon: Code2,
  },
  {
    title: "Live Preview",
    url: "/preview",
    icon: Monitor,
  },
  {
    title: "Integrations",
    url: "/integrations",
    icon: Puzzle,
  },
  {
    title: "Deploy",
    url: "/deploy",
    icon: Rocket,
  },
]

const managementItems = [
  {
    title: "Time Tracking",
    url: "/billing",
    icon: Clock,
  },
  {
    title: "Analytics",
    url: "/analytics",
    icon: BarChart3,
    badge: "New",
  },
  {
    title: "Team",
    url: "/team",
    icon: Users,
  },
]

const systemItems = [
  {
    title: "AI Settings",
    url: "/ai-preferences",
    icon: Wand2,
  },
  {
    title: "Settings",
    url: "/settings",
    icon: Settings,
  },
]

interface EnterpriseSidebarProps {
  currentPath: string
  onNavigate: (path: string) => void
}

export function EnterpriseSidebar({ currentPath, onNavigate }: EnterpriseSidebarProps) {
  return (
    <Sidebar className="border-r border-gray-200">
      <SidebarHeader className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
              <Code2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-900">WorkflowAI</h2>
              <p className="text-xs text-gray-500">Enterprise Edition</p>
            </div>
          </div>
          <ThemeToggle />
        </div>
      </SidebarHeader>

      <SidebarContent className="px-3">
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-medium text-gray-500 uppercase tracking-wider px-3 py-2">
            Project Workflow
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {workflowItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={currentPath === item.url}
                    onClick={() => onNavigate(item.url)}
                    className="w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <button className="w-full flex items-center">
                      <item.icon className="w-4 h-4 mr-3 text-gray-500" />
                      <span className="text-gray-700">{item.title}</span>
                      {item.badge && (
                        <Badge
                          variant={item.badge === "New" ? "default" : "secondary"}
                          className="ml-auto text-xs bg-blue-100 text-blue-700 border-blue-200"
                        >
                          {item.badge}
                        </Badge>
                      )}
                    </button>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-medium text-gray-500 uppercase tracking-wider px-3 py-2">
            Development
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {developmentItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={currentPath === item.url}
                    onClick={() => onNavigate(item.url)}
                    className="w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <button className="w-full flex items-center">
                      <item.icon className="w-4 h-4 mr-3 text-gray-500" />
                      <span className="text-gray-700">{item.title}</span>
                    </button>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-medium text-gray-500 uppercase tracking-wider px-3 py-2">
            Management
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {managementItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={currentPath === item.url}
                    onClick={() => onNavigate(item.url)}
                    className="w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <button className="w-full flex items-center">
                      <item.icon className="w-4 h-4 mr-3 text-gray-500" />
                      <span className="text-gray-700">{item.title}</span>
                      {item.badge && (
                        <Badge
                          variant="secondary"
                          className="ml-auto text-xs bg-green-100 text-green-700 border-green-200"
                        >
                          {item.badge}
                        </Badge>
                      )}
                    </button>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-medium text-gray-500 uppercase tracking-wider px-3 py-2">
            System
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {systemItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={currentPath === item.url}
                    onClick={() => onNavigate(item.url)}
                    className="w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <button className="w-full flex items-center">
                      <item.icon className="w-4 h-4 mr-3 text-gray-500" />
                      <span className="text-gray-700">{item.title}</span>
                    </button>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-gray-200">
        <div className="text-xs text-gray-500">
          <p className="font-medium">WorkflowAI Enterprise</p>
          <p>Version 2.1.0</p>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
