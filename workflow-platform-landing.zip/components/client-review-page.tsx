"use client"

import { useState } from "react"
import { MobilePreview } from "./mobile-preview"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { MessageSquare, CheckCircle, Share2, Copy, Mail, Eye, User, ExternalLink } from "lucide-react"

interface ClientReviewPageProps {
  screens: any[]
  currentScreen: number
  onScreenChange: (index: number) => void
  onAddComment: (screenId: string, x: number, y: number, text: string) => void
  onNavigate: (path: string) => void
}

export function ClientReviewPage({
  screens,
  currentScreen,
  onScreenChange,
  onAddComment,
  onNavigate,
}: ClientReviewPageProps) {
  const [showShareModal, setShowShareModal] = useState(false)
  const [clientEmail, setClientEmail] = useState("")
  const [shareMessage, setShareMessage] = useState(
    "Hi! Please review the latest design mockups for your project. Click the link below to view and add comments.",
  )
  const [linkCopied, setLinkCopied] = useState(false)

  const shareableLink = "https://workflowai.com/review/ecommerce-app-v2?token=abc123xyz"

  const copyLink = () => {
    navigator.clipboard.writeText(shareableLink)
    setLinkCopied(true)
    setTimeout(() => setLinkCopied(false), 2000)
  }

  const sendEmailInvite = () => {
    // In a real app, this would send an actual email
    console.log("Sending email to:", clientEmail)
    console.log("Message:", shareMessage)
    setShowShareModal(false)
    // Show success message
  }

  const totalComments = screens.reduce((sum, screen) => sum + screen.comments.length, 0)

  return (
    <div className="p-6">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Client Review</h1>
            <p className="text-gray-600">Collaborate with your client on design feedback</p>
          </div>
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="text-sm">
              <MessageSquare className="w-4 h-4 mr-1" />
              {totalComments} Comments
            </Badge>
            <Button onClick={() => setShowShareModal(true)}>
              <Share2 className="w-4 h-4 mr-2" />
              Share with Client
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Mobile Preview */}
        <div className="lg:col-span-3 flex justify-center">
          <MobilePreview
            screens={screens}
            currentScreen={currentScreen}
            onScreenChange={onScreenChange}
            onAddComment={onAddComment}
            isReviewMode={true}
          />
        </div>

        {/* Review Panel */}
        <div className="space-y-6">
          {/* Review Status */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Review Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Screens</span>
                <span className="font-semibold">{screens.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Comments</span>
                <span className="font-semibold">{totalComments}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Status</span>
                <Badge variant="secondary">In Review</Badge>
              </div>
            </CardContent>
          </Card>

          {/* Recent Comments */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Recent Comments</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {screens
                .flatMap((screen) => screen.comments)
                .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                .slice(0, 3)
                .map((comment) => (
                  <div key={comment.id} className="border-l-2 border-blue-200 pl-3">
                    <div className="flex items-center space-x-2 mb-1">
                      <User className="w-3 h-3 text-gray-400" />
                      <span className="text-xs font-medium">{comment.author}</span>
                      <span className="text-xs text-gray-500">{comment.timestamp}</span>
                    </div>
                    <p className="text-sm text-gray-700">{comment.text}</p>
                  </div>
                ))}

              {totalComments === 0 && (
                <div className="text-center py-4 text-gray-500">
                  <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No comments yet</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" size="sm" className="w-full justify-start">
                <MessageSquare className="w-4 h-4 mr-2" />
                Add General Comment
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Eye className="w-4 h-4 mr-2" />
                Preview Mode
              </Button>
              <Button size="sm" className="w-full justify-start" onClick={() => onNavigate("/approve")}>
                <CheckCircle className="w-4 h-4 mr-2" />
                Ready for Approval
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md mx-4">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Share Design with Client</CardTitle>
                <Button size="sm" variant="ghost" onClick={() => setShowShareModal(false)}>
                  ×
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Shareable Link */}
              <div>
                <Label className="text-sm font-medium">Shareable Link</Label>
                <div className="flex items-center space-x-2 mt-1">
                  <Input value={shareableLink} readOnly className="text-sm" />
                  <Button size="sm" onClick={copyLink}>
                    {linkCopied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
                <p className="text-xs text-gray-600 mt-1">This link allows clients to view and comment on designs</p>
              </div>

              {/* Email Invitation */}
              <div className="border-t pt-4">
                <Label htmlFor="client-email" className="text-sm font-medium">
                  Send Email Invitation
                </Label>
                <Input
                  id="client-email"
                  type="email"
                  placeholder="client@company.com"
                  value={clientEmail}
                  onChange={(e) => setClientEmail(e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="share-message" className="text-sm font-medium">
                  Message
                </Label>
                <Textarea
                  id="share-message"
                  rows={3}
                  value={shareMessage}
                  onChange={(e) => setShareMessage(e.target.value)}
                  className="mt-1"
                />
              </div>

              <div className="flex space-x-2 pt-2">
                <Button variant="outline" size="sm" onClick={copyLink} className="flex-1">
                  <Copy className="w-4 h-4 mr-2" />
                  {linkCopied ? "Copied!" : "Copy Link"}
                </Button>
                <Button size="sm" onClick={sendEmailInvite} disabled={!clientEmail} className="flex-1">
                  <Mail className="w-4 h-4 mr-2" />
                  Send Email
                </Button>
              </div>

              {/* Link Preview */}
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <ExternalLink className="w-4 h-4 text-gray-500" />
                  <span className="text-sm font-medium">Client Preview</span>
                </div>
                <p className="text-xs text-gray-600">
                  Clients will see a clean, comment-enabled version of your designs without access to project settings
                  or code.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
