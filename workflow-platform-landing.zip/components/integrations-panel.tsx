"use client"

import { useState } from "react"
import { Check, Settings, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const integrations = [
  {
    id: "stripe",
    name: "Stripe",
    description: "Payment processing and subscriptions",
    category: "Payments",
    enabled: true,
    configured: true,
    logo: "💳",
    config: {
      publishableKey: "pk_test_...",
      webhookUrl: "https://api.yourapp.com/webhooks/stripe",
    },
  },
  {
    id: "firebase",
    name: "Firebase",
    description: "Authentication, database, and hosting",
    category: "Backend",
    enabled: true,
    configured: true,
    logo: "🔥",
    config: {
      projectId: "your-project-id",
      apiKey: "AIza...",
    },
  },
  {
    id: "jira",
    name: "Jira",
    description: "Project management and issue tracking",
    category: "Project Management",
    enabled: false,
    configured: false,
    logo: "🎯",
    config: {
      domain: "",
      email: "",
      apiToken: "",
    },
  },
  {
    id: "linear",
    name: "Linear",
    description: "Modern issue tracking and project management",
    category: "Project Management",
    enabled: false,
    configured: false,
    logo: "📈",
    config: {
      apiKey: "",
      teamId: "",
    },
  },
  {
    id: "figma",
    name: "Figma",
    description: "Design collaboration and prototyping",
    category: "Design",
    enabled: false,
    configured: false,
    logo: "🎨",
    config: {
      personalAccessToken: "",
      teamId: "",
    },
  },
  {
    id: "mixpanel",
    name: "Mixpanel",
    description: "Product analytics and user tracking",
    category: "Analytics",
    enabled: false,
    configured: false,
    logo: "📊",
    config: {},
  },
  {
    id: "sendgrid",
    name: "SendGrid",
    description: "Email delivery and marketing",
    category: "Communication",
    enabled: false,
    configured: false,
    logo: "📧",
    config: {},
  },
  {
    id: "pusher",
    name: "Pusher",
    description: "Real-time messaging and notifications",
    category: "Communication",
    enabled: true,
    configured: false,
    logo: "🔔",
    config: {},
  },
  {
    id: "cloudinary",
    name: "Cloudinary",
    description: "Image and video management",
    category: "Media",
    enabled: false,
    configured: false,
    logo: "☁️",
    config: {},
  },
]

export function IntegrationsPanel() {
  const [integrationList, setIntegrationList] = useState(integrations)
  const [selectedIntegration, setSelectedIntegration] = useState<string | null>(null)

  const toggleIntegration = (id: string) => {
    setIntegrationList((prev) =>
      prev.map((integration) =>
        integration.id === id ? { ...integration, enabled: !integration.enabled } : integration,
      ),
    )
  }

  const categories = [...new Set(integrationList.map((i) => i.category))]
  const selectedConfig = integrationList.find((i) => i.id === selectedIntegration)

  return (
    <div className="h-full flex">
      {/* Integrations List */}
      <div className="flex-1 p-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-2">Integrations</h2>
          <p className="text-gray-600">Connect your favorite tools and services</p>
        </div>

        {categories.map((category) => (
          <div key={category} className="mb-8">
            <h3 className="text-lg font-semibold mb-4">{category}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {integrationList
                .filter((integration) => integration.category === category)
                .map((integration) => (
                  <Card
                    key={integration.id}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      integration.enabled ? "ring-2 ring-green-200" : ""
                    }`}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <span className="text-2xl">{integration.logo}</span>
                          <div>
                            <CardTitle className="text-base">{integration.name}</CardTitle>
                            <p className="text-sm text-gray-600">{integration.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {integration.configured && (
                            <Badge variant="outline" className="text-xs">
                              <Check className="w-3 h-3 mr-1" />
                              Configured
                            </Badge>
                          )}
                          <Switch
                            checked={integration.enabled}
                            onCheckedChange={() => toggleIntegration(integration.id)}
                          />
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex justify-between items-center">
                        <div className="flex space-x-2">
                          {integration.enabled && !integration.configured && (
                            <Button size="sm" variant="outline" onClick={() => setSelectedIntegration(integration.id)}>
                              <Settings className="w-4 h-4 mr-2" />
                              Configure
                            </Button>
                          )}
                          {integration.configured && (
                            <Button size="sm" variant="ghost" onClick={() => setSelectedIntegration(integration.id)}>
                              <Settings className="w-4 h-4 mr-2" />
                              Settings
                            </Button>
                          )}
                        </div>
                        <Button size="sm" variant="ghost">
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </div>
        ))}
      </div>

      {/* Configuration Panel */}
      {selectedIntegration && selectedConfig && (
        <div className="w-96 border-l bg-gray-50 p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <span className="text-2xl">{selectedConfig.logo}</span>
              <div>
                <h3 className="font-semibold">{selectedConfig.name}</h3>
                <p className="text-sm text-gray-600">Configuration</p>
              </div>
            </div>
            <Button size="sm" variant="ghost" onClick={() => setSelectedIntegration(null)}>
              ×
            </Button>
          </div>

          <div className="space-y-4">
            {selectedConfig.id === "stripe" && (
              <>
                <div>
                  <Label htmlFor="stripe-key">Publishable Key</Label>
                  <Input
                    id="stripe-key"
                    placeholder="pk_test_..."
                    defaultValue={selectedConfig.config.publishableKey}
                  />
                </div>
                <div>
                  <Label htmlFor="stripe-webhook">Webhook URL</Label>
                  <Input
                    id="stripe-webhook"
                    placeholder="https://..."
                    defaultValue={selectedConfig.config.webhookUrl}
                  />
                </div>
              </>
            )}

            {selectedConfig.id === "firebase" && (
              <>
                <div>
                  <Label htmlFor="firebase-project">Project ID</Label>
                  <Input
                    id="firebase-project"
                    placeholder="your-project-id"
                    defaultValue={selectedConfig.config.projectId}
                  />
                </div>
                <div>
                  <Label htmlFor="firebase-key">API Key</Label>
                  <Input id="firebase-key" placeholder="AIza..." defaultValue={selectedConfig.config.apiKey} />
                </div>
              </>
            )}

            {selectedConfig.id === "jira" && (
              <>
                <div>
                  <Label htmlFor="jira-domain">Jira Domain</Label>
                  <Input
                    id="jira-domain"
                    placeholder="yourcompany.atlassian.net"
                    defaultValue={selectedConfig.config.domain}
                  />
                </div>
                <div>
                  <Label htmlFor="jira-email">Email</Label>
                  <Input
                    id="jira-email"
                    type="email"
                    placeholder="user@company.com"
                    defaultValue={selectedConfig.config.email}
                  />
                </div>
                <div>
                  <Label htmlFor="jira-token">API Token</Label>
                  <Input
                    id="jira-token"
                    type="password"
                    placeholder="Your Jira API token"
                    defaultValue={selectedConfig.config.apiToken}
                  />
                </div>
              </>
            )}

            {selectedConfig.id === "linear" && (
              <>
                <div>
                  <Label htmlFor="linear-key">API Key</Label>
                  <Input
                    id="linear-key"
                    type="password"
                    placeholder="lin_api_..."
                    defaultValue={selectedConfig.config.apiKey}
                  />
                </div>
                <div>
                  <Label htmlFor="linear-team">Team ID</Label>
                  <Input id="linear-team" placeholder="team_..." defaultValue={selectedConfig.config.teamId} />
                </div>
              </>
            )}

            {selectedConfig.id === "figma" && (
              <>
                <div>
                  <Label htmlFor="figma-token">Personal Access Token</Label>
                  <Input
                    id="figma-token"
                    type="password"
                    placeholder="figd_..."
                    defaultValue={selectedConfig.config.personalAccessToken}
                  />
                </div>
                <div>
                  <Label htmlFor="figma-team">Team ID (Optional)</Label>
                  <Input id="figma-team" placeholder="123456789" defaultValue={selectedConfig.config.teamId} />
                </div>
              </>
            )}

            {!selectedConfig.configured && (
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Getting Started</h4>
                <p className="text-sm text-blue-700 mb-3">Follow these steps to configure {selectedConfig.name}:</p>
                <ol className="text-sm text-blue-700 space-y-1">
                  {selectedConfig.id === "jira" && (
                    <>
                      <li>1. Go to your Jira settings → Security → API tokens</li>
                      <li>2. Create a new API token</li>
                      <li>3. Enter your domain, email, and token above</li>
                      <li>4. Test the connection</li>
                    </>
                  )}
                  {selectedConfig.id === "linear" && (
                    <>
                      <li>1. Go to Linear Settings → API</li>
                      <li>2. Create a new personal API key</li>
                      <li>3. Find your team ID in the URL or settings</li>
                      <li>4. Test the connection</li>
                    </>
                  )}
                  {selectedConfig.id === "figma" && (
                    <>
                      <li>1. Go to Figma Settings → Personal access tokens</li>
                      <li>2. Generate a new token</li>
                      <li>3. Optionally add your team ID for team files</li>
                      <li>4. Test the connection</li>
                    </>
                  )}
                  {!["jira", "linear", "figma"].includes(selectedConfig.id) && (
                    <>
                      <li>1. Create an account at {selectedConfig.name}</li>
                      <li>2. Get your API keys from the dashboard</li>
                      <li>3. Enter the keys in the form above</li>
                      <li>4. Test the connection</li>
                    </>
                  )}
                </ol>
              </div>
            )}

            <div className="flex space-x-2 pt-4">
              <Button size="sm" className="flex-1">
                Save Configuration
              </Button>
              <Button size="sm" variant="outline">
                Test Connection
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
