"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Plus, Clock, MessageSquare, DollarSign, Eye, MoreHorizontal, Smartphone, Users, Calendar } from "lucide-react"

const projects = [
  {
    id: "1",
    name: "E-commerce App",
    client: "TechCorp Inc.",
    status: "In Progress",
    progress: 65,
    timeSpent: "24.5 hrs",
    comments: 3,
    revenue: "$2,450",
    lastActivity: "2 hours ago",
    screens: 8,
    team: ["John", "Sarah"],
    deadline: "Dec 15, 2024",
    color: "bg-blue-500",
  },
  {
    id: "2",
    name: "Fitness Tracker",
    client: "HealthTech Solutions",
    status: "Review",
    progress: 85,
    timeSpent: "18.2 hrs",
    comments: 1,
    revenue: "$1,820",
    lastActivity: "1 day ago",
    screens: 12,
    team: ["Mike", "Lisa"],
    deadline: "Dec 10, 2024",
    color: "bg-green-500",
  },
  {
    id: "3",
    name: "Food Delivery",
    client: "QuickEats",
    status: "Design",
    progress: 30,
    timeSpent: "12.8 hrs",
    comments: 7,
    revenue: "$1,280",
    lastActivity: "3 hours ago",
    screens: 15,
    team: ["Alex"],
    deadline: "Jan 5, 2025",
    color: "bg-orange-500",
  },
  {
    id: "4",
    name: "Banking App",
    client: "SecureBank",
    status: "Planning",
    progress: 10,
    timeSpent: "4.5 hrs",
    comments: 0,
    revenue: "$450",
    lastActivity: "1 week ago",
    screens: 0,
    team: ["John", "Sarah", "Mike"],
    deadline: "Feb 1, 2025",
    color: "bg-purple-500",
  },
]

const getStatusColor = (status: string) => {
  switch (status) {
    case "In Progress":
      return "bg-blue-100 text-blue-800"
    case "Review":
      return "bg-yellow-100 text-yellow-800"
    case "Design":
      return "bg-purple-100 text-purple-800"
    case "Planning":
      return "bg-gray-100 text-gray-800"
    case "Complete":
      return "bg-green-100 text-green-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

interface ProjectDashboardProps {
  onProjectSelect: (projectId: string) => void
}

export function ProjectDashboard({ onProjectSelect }: ProjectDashboardProps) {
  const [selectedProject, setSelectedProject] = useState("1")

  const totalHours = projects.reduce((sum, p) => sum + Number.parseFloat(p.timeSpent), 0)
  const totalRevenue = projects.reduce((sum, p) => sum + Number.parseInt(p.revenue.replace(/[$,]/g, "")), 0)
  const totalComments = projects.reduce((sum, p) => sum + p.comments, 0)

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Project Dashboard</h1>
          <p className="text-gray-600">Manage all your app development projects</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          New Project
        </Button>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center">
              <Smartphone className="w-5 h-5 mr-2 text-blue-500" />
              Active Projects
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{projects.length}</div>
            <p className="text-sm text-gray-600">Total projects</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center">
              <Clock className="w-5 h-5 mr-2 text-green-500" />
              Total Hours
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalHours.toFixed(1)}</div>
            <p className="text-sm text-gray-600">Across all projects</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center">
              <MessageSquare className="w-5 h-5 mr-2 text-orange-500" />
              Comments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalComments}</div>
            <p className="text-sm text-gray-600">Pending review</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center">
              <DollarSign className="w-5 h-5 mr-2 text-purple-500" />
              Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalRevenue.toLocaleString()}</div>
            <p className="text-sm text-gray-600">Total billable</p>
          </CardContent>
        </Card>
      </div>

      {/* Projects Grid */}
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-4">Your Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <Card
              key={project.id}
              className={`cursor-pointer transition-all hover:shadow-lg ${
                selectedProject === project.id ? "ring-2 ring-blue-500" : ""
              }`}
              onClick={() => {
                setSelectedProject(project.id)
                onProjectSelect(project.id)
              }}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className={`w-3 h-3 rounded-full ${project.color}`}></div>
                      <CardTitle className="text-lg">{project.name}</CardTitle>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{project.client}</p>
                    <Badge className={`text-xs ${getStatusColor(project.status)}`}>{project.status}</Badge>
                  </div>
                  <Button size="sm" variant="ghost">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Progress</span>
                    <span>{project.progress}%</span>
                  </div>
                  <Progress value={project.progress} className="h-2" />
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-gray-400" />
                    <span>{project.timeSpent}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Smartphone className="w-4 h-4 text-gray-400" />
                    <span>{project.screens} screens</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MessageSquare className="w-4 h-4 text-gray-400" />
                    <span>{project.comments} comments</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-gray-400" />
                    <span>{project.team.length} team</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Calendar className="w-4 h-4" />
                    <span>{project.deadline}</span>
                  </div>
                  <div className="text-sm font-semibold text-green-600">{project.revenue}</div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">Last activity: {project.lastActivity}</span>
                  <Button size="sm" variant="outline">
                    <Eye className="w-4 h-4 mr-1" />
                    Open
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center space-x-3">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-sm">E-commerce App: Client added 2 comments</span>
            <span className="text-xs text-gray-500 ml-auto">2h ago</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            <span className="text-sm">Fitness Tracker: Design approved and locked</span>
            <span className="text-xs text-gray-500 ml-auto">1d ago</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
            <span className="text-sm">Food Delivery: AI generated 5 new screens</span>
            <span className="text-xs text-gray-500 ml-auto">3h ago</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
            <span className="text-sm">Banking App: Project brief updated</span>
            <span className="text-xs text-gray-500 ml-auto">1w ago</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
