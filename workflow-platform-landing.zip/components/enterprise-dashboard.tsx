"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Plus,
  Clock,
  MessageSquare,
  DollarSign,
  TrendingUp,
  Users,
  Calendar,
  MoreHorizontal,
  ArrowUpRight,
  CheckCircle2,
  AlertCircle,
  Pause,
  Play,
} from "lucide-react"

const projects = [
  {
    id: "1",
    name: "E-commerce Platform",
    client: "TechCorp Inc.",
    status: "In Progress",
    priority: "High",
    progress: 68,
    timeSpent: "156.5 hrs",
    budget: "$45,000",
    spent: "$28,500",
    comments: 3,
    lastActivity: "2 hours ago",
    screens: 24,
    team: [
      { name: "John Smith", role: "Lead Developer" },
      { name: "Sarah Chen", role: "UI Designer" },
      { name: "Mike Johnson", role: "Backend Dev" },
    ],
    deadline: "Dec 15, 2024",
    health: "good",
  },
  {
    id: "2",
    name: "Healthcare Dashboard",
    client: "MedTech Solutions",
    status: "Review",
    priority: "Medium",
    progress: 85,
    timeSpent: "89.2 hrs",
    budget: "$32,000",
    spent: "$27,200",
    comments: 1,
    lastActivity: "1 day ago",
    screens: 18,
    team: [
      { name: "Lisa Wang", role: "Product Designer" },
      { name: "David Kim", role: "Frontend Dev" },
    ],
    deadline: "Dec 10, 2024",
    health: "excellent",
  },
  {
    id: "3",
    name: "Financial Analytics",
    client: "FinanceFlow",
    status: "Planning",
    priority: "High",
    progress: 15,
    timeSpent: "24.8 hrs",
    budget: "$65,000",
    spent: "$6,500",
    comments: 7,
    lastActivity: "3 hours ago",
    screens: 8,
    team: [
      { name: "Alex Rodriguez", role: "Data Analyst" },
      { name: "Emma Thompson", role: "UX Designer" },
    ],
    deadline: "Jan 15, 2025",
    health: "warning",
  },
]

const getStatusConfig = (status: string) => {
  switch (status) {
    case "In Progress":
      return { color: "bg-blue-50 text-blue-700 border-blue-200", icon: Play }
    case "Review":
      return { color: "bg-amber-50 text-amber-700 border-amber-200", icon: Pause }
    case "Planning":
      return { color: "bg-gray-50 text-gray-700 border-gray-200", icon: Clock }
    case "Complete":
      return { color: "bg-green-50 text-green-700 border-green-200", icon: CheckCircle2 }
    default:
      return { color: "bg-gray-50 text-gray-700 border-gray-200", icon: Clock }
  }
}

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case "High":
      return "bg-red-100 text-red-800 border-red-200"
    case "Medium":
      return "bg-yellow-100 text-yellow-800 border-yellow-200"
    case "Low":
      return "bg-green-100 text-green-800 border-green-200"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

const getHealthColor = (health: string) => {
  switch (health) {
    case "excellent":
      return "bg-green-500"
    case "good":
      return "bg-blue-500"
    case "warning":
      return "bg-amber-500"
    case "critical":
      return "bg-red-500"
    default:
      return "bg-gray-500"
  }
}

interface EnterpriseDashboardProps {
  onProjectSelect: (projectId: string) => void
}

export function EnterpriseDashboard({ onProjectSelect }: EnterpriseDashboardProps) {
  const [selectedProject, setSelectedProject] = useState("1")

  const totalBudget = projects.reduce((sum, p) => sum + Number.parseInt(p.budget.replace(/[$,]/g, "")), 0)
  const totalSpent = projects.reduce((sum, p) => sum + Number.parseInt(p.spent.replace(/[$,]/g, "")), 0)
  const totalHours = projects.reduce((sum, p) => sum + Number.parseFloat(p.timeSpent), 0)
  const activeProjects = projects.filter((p) => p.status === "In Progress").length

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Project Dashboard</h1>
            <p className="text-sm text-gray-600 mt-1">Manage and monitor all development projects</p>
          </div>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            New Project
          </Button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Projects</p>
                  <p className="text-2xl font-semibold text-gray-900 mt-1">{activeProjects}</p>
                  <p className="text-xs text-green-600 mt-1 flex items-center">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    +2 this month
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Play className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Budget</p>
                  <p className="text-2xl font-semibold text-gray-900 mt-1">${totalBudget.toLocaleString()}</p>
                  <p className="text-xs text-gray-500 mt-1">${totalSpent.toLocaleString()} spent</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Hours</p>
                  <p className="text-2xl font-semibold text-gray-900 mt-1">{totalHours.toFixed(1)}</p>
                  <p className="text-xs text-blue-600 mt-1">Across all projects</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Team Members</p>
                  <p className="text-2xl font-semibold text-gray-900 mt-1">12</p>
                  <p className="text-xs text-gray-500 mt-1">Across 3 projects</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Projects Grid */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Active Projects</h2>
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <span>Sorted by priority</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {projects.map((project) => {
              const statusConfig = getStatusConfig(project.status)
              const StatusIcon = statusConfig.icon

              return (
                <Card
                  key={project.id}
                  className={`border-0 shadow-sm hover:shadow-md transition-all cursor-pointer ${
                    selectedProject === project.id ? "ring-2 ring-blue-500 ring-offset-2" : ""
                  }`}
                  onClick={() => {
                    setSelectedProject(project.id)
                    onProjectSelect(project.id)
                  }}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <div className={`w-3 h-3 rounded-full ${getHealthColor(project.health)}`}></div>
                          <h3 className="font-semibold text-gray-900">{project.name}</h3>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">{project.client}</p>

                        <div className="flex items-center space-x-2">
                          <Badge className={`text-xs border ${statusConfig.color}`}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {project.status}
                          </Badge>
                          <Badge variant="outline" className={`text-xs ${getPriorityColor(project.priority)}`}>
                            {project.priority}
                          </Badge>
                        </div>
                      </div>
                      <Button size="sm" variant="ghost" className="text-gray-400 hover:text-gray-600">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    {/* Progress */}
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-gray-600">Progress</span>
                        <span className="font-medium text-gray-900">{project.progress}%</span>
                      </div>
                      <Progress value={project.progress} className="h-2" />
                    </div>

                    {/* Key Metrics */}
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500">Budget</p>
                        <p className="font-medium text-gray-900">{project.budget}</p>
                        <p className="text-xs text-gray-500">{project.spent} spent</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Time</p>
                        <p className="font-medium text-gray-900">{project.timeSpent}</p>
                        <p className="text-xs text-gray-500">{project.screens} screens</p>
                      </div>
                    </div>

                    {/* Team */}
                    <div>
                      <p className="text-sm text-gray-500 mb-2">Team</p>
                      <div className="flex items-center space-x-2">
                        <div className="flex -space-x-2">
                          {project.team.slice(0, 3).map((member, index) => (
                            <Avatar key={index} className="w-6 h-6 border-2 border-white">
                              <AvatarFallback className="text-xs bg-gray-100">
                                {member.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                          ))}
                        </div>
                        <span className="text-xs text-gray-500">
                          {project.team.length} member{project.team.length !== 1 ? "s" : ""}
                        </span>
                      </div>
                    </div>

                    {/* Footer */}
                    <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                      <div className="flex items-center space-x-1 text-xs text-gray-500">
                        <Calendar className="w-3 h-3" />
                        <span>Due {project.deadline}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {project.comments > 0 && (
                          <div className="flex items-center space-x-1 text-xs text-gray-500">
                            <MessageSquare className="w-3 h-3" />
                            <span>{project.comments}</span>
                          </div>
                        )}
                        <Button size="sm" variant="ghost" className="text-blue-600 hover:text-blue-700 h-6 px-2">
                          <ArrowUpRight className="w-3 h-3 mr-1" />
                          Open
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>

        {/* Recent Activity */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  type: "comment",
                  project: "E-commerce Platform",
                  message: "Client added 2 new comments on checkout flow",
                  time: "2 hours ago",
                  icon: MessageSquare,
                  color: "text-blue-600",
                },
                {
                  type: "approval",
                  project: "Healthcare Dashboard",
                  message: "Design approved and moved to development",
                  time: "1 day ago",
                  icon: CheckCircle2,
                  color: "text-green-600",
                },
                {
                  type: "warning",
                  project: "Financial Analytics",
                  message: "Project timeline needs review - potential delay",
                  time: "2 days ago",
                  icon: AlertCircle,
                  color: "text-amber-600",
                },
              ].map((activity, index) => (
                <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50">
                  <div className={`w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0`}>
                    <activity.icon className={`w-4 h-4 ${activity.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">{activity.project}</p>
                    <p className="text-sm text-gray-600">{activity.message}</p>
                    <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
