"use client"

import { useState } from "react"
import {
  Play,
  Download,
  GitBranch,
  Terminal,
  FileCode,
  FolderOpen,
  Github,
  ExternalLink,
  GitCommit,
  Clock,
  Send,
  Wand2,
  Eye,
  Smartphone,
  ChevronUp,
  ChevronDown,
  Undo,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { ThemeToggle } from "./theme-toggle"

interface CodeChange {
  id: string
  prompt: string
  timestamp: string
  description: string
  files: string[]
  author: string
}

const projects = [
  {
    id: "ecommerce",
    name: "E-commerce App",
    status: "Active",
    lastModified: "2 hours ago",
    github: {
      repo: "workflowai/ecommerce-app",
      branch: "main",
      lastSync: "2 m ago",
      lastCommit: "feat: add product filtering",
      commitHash: "a1b2c3d",
      url: "https://github.com/workflowai/ecommerce-app",
    },
    files: [
      {
        name: "App.tsx",
        language: "typescript",
        content: `import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './screens/HomeScreen';
import ProductScreen from './screens/ProductScreen';
import CartScreen from './screens/CartScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Product" component={ProductScreen} />
        <Stack.Screen name="Cart" component={CartScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}`,
      },
      {
        name: "HomeScreen.tsx",
        language: "typescript",
        content: `import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';

const products = [
  { id: '1', name: 'Wireless Headphones', price: '$99.99', image: 'headphones.jpg' },
  { id: '2', name: 'Smart Watch', price: '$199.99', image: 'watch.jpg' },
  { id: '3', name: 'Phone Case', price: '$29.99', image: 'case.jpg' },
];

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to TechStore</Text>
      <Text style={styles.subtitle}>Discover amazing products</Text>
      
      <FlatList
        data={products}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={styles.productItem}
            onPress={() => navigation.navigate('Product', { product: item })}
          >
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productPrice}>{item.price}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#333',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: 20,
  },
  productItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    backgroundColor: '#f9f9f9',
    marginBottom: 10,
    borderRadius: 8,
  },
  productName: {
    fontSize: 18,
    fontWeight: '600',
  },
  productPrice: {
    fontSize: 16,
    color: '#007AFF',
    marginTop: 5,
    fontWeight: 'bold',
  },
});`,
      },
      {
        name: "package.json",
        language: "json",
        content: `{
  "name": "ecommerce-app",
  "version": "1.0.0",
  "main": "node_modules/expo/AppEntry.js",
  "scripts": {
    "start": "expo start",
    "android": "expo start --android",
    "ios": "expo start --ios",
    "web": "expo start --web"
  },
  "dependencies": {
    "@react-navigation/native": "^6.1.9",
    "@react-navigation/stack": "^6.3.20",
    "expo": "~49.0.15",
    "react": "18.2.0",
    "react-native": "0.72.6",
    "react-native-vector-icons": "^10.0.0"
  }
}`,
      },
    ],
  },
  {
    id: "fitness",
    name: "Fitness Tracker",
    status: "Review",
    lastModified: "1 day ago",
    github: {
      repo: "workflowai/fitness-tracker",
      branch: "develop",
      lastSync: "1 h ago",
      lastCommit: "fix: workout timer bug",
      commitHash: "x9y8z7w",
      url: "https://github.com/workflowai/fitness-tracker",
    },
    files: [
      {
        name: "App.tsx",
        language: "typescript",
        content: `import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import DashboardScreen from './screens/DashboardScreen';
import WorkoutScreen from './screens/WorkoutScreen';
import ProfileScreen from './screens/ProfileScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Dashboard" component={DashboardScreen} />
        <Tab.Screen name="Workout" component={WorkoutScreen} />
        <Tab.Screen name="Profile" component={ProfileScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}`,
      },
      {
        name: "DashboardScreen.tsx",
        language: "typescript",
        content: `import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function DashboardScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Fitness Dashboard</Text>
      
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>12,543</Text>
          <Text style={styles.statLabel}>Steps Today</Text>
        </View>
        
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>2.1</Text>
          <Text style={styles.statLabel}>Miles</Text>
        </View>
        
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>340</Text>
          <Text style={styles.statLabel}>Calories</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    padding: 20,
    color: '#333',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 20,
  },
  statCard: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
    minWidth: 100,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#007AFF',
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 5,
  },
});`,
      },
      {
        name: "package.json",
        language: "json",
        content: `{
  "name": "fitness-tracker",
  "version": "1.0.0",
  "main": "node_modules/expo/AppEntry.js",
  "scripts": {
    "start": "expo start",
    "android": "expo start --android",
    "ios": "expo start --ios"
  },
  "dependencies": {
    "@react-navigation/bottom-tabs": "^6.5.11",
    "@react-navigation/native": "^6.1.9",
    "expo": "~49.0.15",
    "react": "18.2.0",
    "react-native": "0.72.6"
  }
}`,
      },
    ],
  },
  {
    id: "food-delivery",
    name: "Food Delivery",
    status: "Development",
    lastModified: "3 hours ago",
    github: {
      repo: "workflowai/food-delivery-app",
      branch: "feature/restaurant-search",
      lastSync: "5 m ago",
      lastCommit: "add: restaurant filtering logic",
      commitHash: "m5n4o3p",
      url: "https://github.com/workflowai/food-delivery-app",
    },
    files: [
      {
        name: "App.tsx",
        language: "typescript",
        content: `import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import RestaurantListScreen from './screens/RestaurantListScreen';
import MenuScreen from './screens/MenuScreen';
import OrderScreen from './screens/OrderScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Restaurants" component={RestaurantListScreen} />
        <Stack.Screen name="Menu" component={MenuScreen} />
        <Stack.Screen name="Order" component={OrderScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}`,
      },
      {
        name: "RestaurantListScreen.tsx",
        language: "typescript",
        content: `import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';

const restaurants = [
  { id: '1', name: 'Pizza Palace', cuisine: 'Italian', rating: 4.5, deliveryTime: '25-35 min' },
  { id: '2', name: 'Burger Barn', cuisine: 'American', rating: 4.2, deliveryTime: '20-30 min' },
  { id: '3', name: 'Sushi Spot', cuisine: 'Japanese', rating: 4.8, deliveryTime: '30-40 min' },
];

export default function RestaurantListScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Restaurants Near You</Text>
      
      <FlatList
        data={restaurants}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={styles.restaurantCard}
            onPress={() => navigation.navigate('Menu', { restaurant: item })}
          >
            <View style={styles.restaurantInfo}>
              <Text style={styles.restaurantName}>{item.name}</Text>
              <Text style={styles.cuisine}>{item.cuisine}</Text>
              <Text style={styles.details}>⭐ {item.rating} • {item.deliveryTime}</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  restaurantCard: {
    backgroundColor: '#f9f9f9',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#eee',
  },
  restaurantInfo: {
    flex: 1,
  },
  restaurantName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  cuisine: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  details: {
    fontSize: 12,
    color: '#999',
    marginTop: 8,
  },
});`,
      },
      {
        name: "package.json",
        language: "json",
        content: `{
  "name": "food-delivery-app",
  "version": "1.0.0",
  "main": "node_modules/expo/AppEntry.js",
  "scripts": {
    "start": "expo start",
    "android": "expo start --android",
    "ios": "expo start --ios"
  },
  "dependencies": {
    "@react-navigation/native": "^6.1.9",
    "@react-navigation/stack": "^6.3.20",
    "expo": "~49.0.15",
    "react": "18.2.0",
    "react-native": "0.72.6",
    "react-native-maps": "^1.7.1"
  }
}`,
      },
    ],
  },
]

export function CodeEditor() {
  const [selectedProject, setSelectedProject] = useState(projects[0])
  const [activeFile, setActiveFile] = useState(0)
  const [isRunning, setIsRunning] = useState(false)
  const [prompt, setPrompt] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [showTerminal, setShowTerminal] = useState(false)
  const [codeChanges, setCodeChanges] = useState<CodeChange[]>([
    {
      id: "1",
      prompt: "Add error handling to the API calls",
      timestamp: "1 hour ago",
      description: "Added try-catch blocks and error states to all API calls",
      files: ["HomeScreen.tsx", "ProductScreen.tsx"],
      author: "AI Assistant",
    },
    {
      id: "2",
      prompt: "Optimize the FlatList performance with better key extraction",
      timestamp: "2 hours ago",
      description: "Updated keyExtractor and added getItemLayout for better performance",
      files: ["HomeScreen.tsx"],
      author: "AI Assistant",
    },
  ])

  const [viewMode, setViewMode] = useState<"code" | "preview" | "split">("code")

  const [codeVersions, setCodeVersions] = useState<{ [key: string]: CodeChange[] }>({
    [selectedProject.id]: [],
  })

  const revertToVersion = (changeId: string) => {
    const projectVersions = codeVersions[selectedProject.id] || []
    const changeIndex = projectVersions.findIndex((change) => change.id === changeId)

    if (changeIndex !== -1) {
      // Remove all changes after this version
      const newVersions = projectVersions.slice(0, changeIndex + 1)
      setCodeVersions((prev) => ({
        ...prev,
        [selectedProject.id]: newVersions,
      }))

      // Update the displayed changes
      setCodeChanges(newVersions)

      // In a real implementation, this would also revert the actual code files
      console.log(`Reverted to version: ${changeId}`)
    }
  }

  const runCode = () => {
    setIsRunning(true)
    setTimeout(() => setIsRunning(false), 2000)
  }

  const handlePromptSubmit = async () => {
    if (!prompt.trim()) return

    setIsGenerating(true)

    // Simulate AI processing
    setTimeout(() => {
      const newChange: CodeChange = {
        id: Date.now().toString(),
        prompt: prompt,
        timestamp: "Just now",
        description: "Applied requested changes to the codebase",
        files: [selectedProject.files[activeFile].name],
        author: "AI Assistant",
      }

      const updatedChanges = [newChange, ...codeChanges]
      setCodeChanges(updatedChanges)

      // Save to versions history
      setCodeVersions((prev) => ({
        ...prev,
        [selectedProject.id]: updatedChanges,
      }))

      setPrompt("")
      setIsGenerating(false)
    }, 2000)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800"
      case "Review":
        return "bg-yellow-100 text-yellow-800"
      case "Development":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const openGitHubRepo = () => {
    window.open(selectedProject.github.url, "_blank")
  }

  return (
    <div className="h-screen flex bg-background overflow-hidden">
      {/* Left Panel - AI Assistant with Chat History */}
      <div className="w-96 bg-card border-r border-border flex flex-col h-full">
        {/* AI Assistant Header */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <SidebarTrigger />
              <div className="flex items-center space-x-3">{/* Empty div to maintain spacing */}</div>
            </div>
            <ThemeToggle />
          </div>
          <p className="text-sm text-muted-foreground mt-1">Make code changes using natural language</p>
        </div>

        {/* Chat History */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-6">
            {codeChanges.map((change) => (
              <div key={change.id} className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-medium text-blue-600">You</span>
                  </div>
                  <div className="flex-1">
                    <div className="bg-blue-600 text-white p-3 rounded-lg rounded-tl-none">
                      <p className="text-sm">{change.prompt}</p>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{change.timestamp}</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Wand2 className="w-4 h-4 text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <div className="bg-muted p-3 rounded-lg rounded-tl-none">
                      <p className="text-sm text-foreground">{change.description}</p>
                      {change.files.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {change.files.map((file) => (
                            <Badge key={file} variant="outline" className="text-xs">
                              {file}
                            </Badge>
                          ))}
                        </div>
                      )}
                      <div className="flex items-center justify-between mt-2">
                        <p className="text-xs text-muted-foreground">
                          {change.author} • {change.timestamp}
                        </p>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => revertToVersion(change.id)}
                          className="text-xs h-6 px-2 text-blue-600 hover:text-blue-800 flex items-center space-x-1"
                        >
                          <Undo className="w-3 h-3" />
                          <span>Revert</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {isGenerating && (
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-medium text-blue-600">You</span>
                  </div>
                  <div className="flex-1">
                    <div className="bg-blue-600 text-white p-3 rounded-lg rounded-tl-none">
                      <p className="text-sm">{prompt}</p>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Just now</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Wand2 className="w-4 h-4 text-purple-600 animate-pulse" />
                  </div>
                  <div className="flex-1">
                    <div className="bg-muted p-3 rounded-lg rounded-tl-none">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                        <div
                          className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {codeChanges.length === 0 && !isGenerating && (
              <div className="text-center py-8 text-muted-foreground">
                <Wand2 className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Start a conversation</p>
                <p className="text-xs">Ask me to modify your code</p>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Quick Suggestions */}
        <div className="p-4 border-t border-border">
          <div className="mb-3">
            <span className="text-sm font-medium text-foreground">Suggestions</span>
          </div>
          <div className="space-y-2">
            {["Add error handling", "Optimize performance", "Add TypeScript types", "Improve accessibility"].map(
              (suggestion) => (
                <Button
                  key={suggestion}
                  size="sm"
                  variant="outline"
                  onClick={() => setPrompt(suggestion)}
                  className="w-full justify-start text-left h-auto p-2"
                >
                  <span className="text-xs">{suggestion}</span>
                </Button>
              ),
            )}
          </div>
        </div>

        {/* Chat Input */}
        <div className="p-4 border-t border-border">
          <div className="relative">
            <Input
              placeholder="Ask me to modify your code..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  handlePromptSubmit()
                }
              }}
              disabled={isGenerating}
              className="pr-12"
            />
            <Button
              size="sm"
              onClick={handlePromptSubmit}
              disabled={!prompt.trim() || isGenerating}
              className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8"
            >
              {isGenerating ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Right Panel - Code Editor and Preview */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Editor Header */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-muted/50">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <FolderOpen className="w-5 h-5 text-muted-foreground" />
              <Select
                value={selectedProject.id}
                onValueChange={(value) => {
                  const project = projects.find((p) => p.id === value)
                  if (project) {
                    setSelectedProject(project)
                    setActiveFile(0)
                  }
                }}
              >
                <SelectTrigger className="w-64">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((project) => (
                    <SelectItem key={project.id} value={project.id}>
                      <div className="flex items-center space-x-2">
                        <span>{project.name}</span>
                        <Badge className={`text-xs ${getStatusColor(project.status)}`}>{project.status}</Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* GitHub Integration */}
            <div className="flex items-center space-x-3">
              <Badge
                variant="outline"
                className="flex items-center space-x-2 px-3 py-1 cursor-pointer hover:bg-muted transition-colors"
                onClick={openGitHubRepo}
              >
                <Github className="w-4 h-4" />
                <span>Synced @ {selectedProject.github.branch}</span>
                <span>•</span>
                <Clock className="w-3 h-3" />
                <span>{selectedProject.github.lastSync}</span>
              </Badge>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <div className="flex items-center border rounded-lg p-1 bg-muted">
              <Button
                size="sm"
                variant={viewMode === "code" ? "default" : "ghost"}
                onClick={() => setViewMode("code")}
                className="h-7 px-3"
              >
                <FileCode className="w-4 h-4 mr-1" />
                Code
              </Button>
              <Button
                size="sm"
                variant={viewMode === "preview" ? "default" : "ghost"}
                onClick={() => setViewMode("preview")}
                className="h-7 px-3"
              >
                <Smartphone className="w-4 h-4 mr-1" />
                Preview
              </Button>
              <Button
                size="sm"
                variant={viewMode === "split" ? "default" : "ghost"}
                onClick={() => setViewMode("split")}
                className="h-7 px-3"
              >
                <Eye className="w-4 h-4 mr-1" />
                Split
              </Button>
            </div>
            <Button size="sm" variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
            <Button size="sm" onClick={runCode} disabled={isRunning}>
              <Play className="w-4 h-4 mr-2" />
              {isRunning ? "Running..." : "Run"}
            </Button>
          </div>
        </div>

        {/* GitHub Status Bar */}
        <div className="px-4 py-2 bg-muted border-b border-border text-sm text-muted-foreground">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <GitBranch className="w-4 h-4" />
                <span className="font-medium">{selectedProject.github.branch}</span>
              </div>
              <div className="flex items-center space-x-2">
                <GitCommit className="w-4 h-4" />
                <span className="font-mono text-xs bg-muted px-2 py-1 rounded">
                  {selectedProject.github.commitHash}
                </span>
                <span>{selectedProject.github.lastCommit}</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>All changes synced</span>
            </div>
          </div>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* File Explorer - Always visible */}
          <div className="w-64 border-r border-border bg-muted/30 flex flex-col overflow-hidden">
            <div className="p-3 border-b border-border flex-shrink-0">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium">{selectedProject.name} Files</h3>
                <Button size="sm" variant="ghost" onClick={openGitHubRepo} className="h-6 w-6 p-0">
                  <ExternalLink className="w-3 h-3" />
                </Button>
              </div>
              <div className="text-xs text-muted-foreground mt-1">{selectedProject.github.repo}</div>
            </div>
            <div className="p-2 flex-1 overflow-auto">
              {selectedProject.files.map((file, index) => (
                <button
                  key={file.name}
                  onClick={() => setActiveFile(index)}
                  className={`w-full text-left p-2 rounded text-sm flex items-center space-x-2 hover:bg-muted transition-colors ${
                    activeFile === index ? "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300" : ""
                  }`}
                >
                  <FileCode className="w-4 h-4" />
                  <span>{file.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 flex">
            {/* Code Editor - Show in code and split modes */}
            {(viewMode === "code" || viewMode === "split") && (
              <div className={`${viewMode === "split" ? "flex-1" : "flex-1"} flex flex-col overflow-hidden`}>
                <div className="flex items-center justify-between p-2 border-b border-border bg-muted/50 flex-shrink-0">
                  <span className="text-sm font-medium">{selectedProject.files[activeFile]?.name}</span>
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                    <span>Auto-sync enabled</span>
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  </div>
                </div>
                <div className="flex-1 p-4 font-mono text-sm bg-gray-900 text-gray-100 overflow-auto">
                  <pre className="whitespace-pre-wrap">
                    <code>{selectedProject.files[activeFile]?.content}</code>
                  </pre>
                </div>
              </div>
            )}

            {/* Preview Area - Show in preview and split modes */}
            {(viewMode === "preview" || viewMode === "split") && (
              <div
                className={`${viewMode === "split" ? "flex-1 border-l border-border" : "flex-1"} flex flex-col bg-muted/30 overflow-hidden`}
              >
                <div className="flex items-center justify-between p-2 border-b border-border bg-muted">
                  <span className="text-sm font-medium flex items-center">
                    <Smartphone className="w-4 h-4 mr-2" />
                    Live Preview
                  </span>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline" className="text-xs">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                      Connected
                    </Badge>
                    <Button size="sm" variant="ghost" onClick={runCode}>
                      <Play className="w-3 h-3" />
                    </Button>
                  </div>
                </div>

                {/* Mobile Preview */}
                <div className="flex-1 flex items-center justify-center p-8">
                  <div className="relative">
                    <div className="w-80 h-[640px] bg-gray-900 rounded-[3rem] p-4 shadow-2xl">
                      <div className="w-full h-full bg-white rounded-[2rem] overflow-hidden relative">
                        {/* Screen Content */}
                        <div className="w-full h-full bg-gray-50 relative overflow-auto">
                          {/* Simulated App Content based on selected project */}
                          {selectedProject.id === "ecommerce" && (
                            <div className="p-6">
                              <div className="text-center mb-6">
                                <h1 className="text-2xl font-bold text-gray-800 mb-2">Welcome to TechStore</h1>
                                <p className="text-gray-600">Discover amazing products</p>
                              </div>

                              <div className="space-y-4">
                                {[
                                  { name: "Wireless Headphones", price: "$99.99" },
                                  { name: "Smart Watch", price: "$199.99" },
                                  { name: "Phone Case", price: "$29.99" },
                                ].map((product, index) => (
                                  <div key={index} className="bg-gray-100 p-4 rounded-lg">
                                    <div className="font-semibold text-gray-800">{product.name}</div>
                                    <div className="text-blue-600 font-bold mt-1">{product.price}</div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {selectedProject.id === "fitness" && (
                            <div className="p-6">
                              <h1 className="text-2xl font-bold text-gray-800 mb-6">Fitness Dashboard</h1>

                              <div className="grid grid-cols-1 gap-4">
                                <div className="bg-white p-4 rounded-lg text-center shadow-sm">
                                  <div className="text-2xl font-bold text-blue-600">12,543</div>
                                  <div className="text-sm text-gray-600">Steps Today</div>
                                </div>
                                <div className="bg-white p-4 rounded-lg text-center shadow-sm">
                                  <div className="text-2xl font-bold text-blue-600">2.1</div>
                                  <div className="text-sm text-gray-600">Miles</div>
                                </div>
                                <div className="bg-white p-4 rounded-lg text-center shadow-sm">
                                  <div className="text-2xl font-bold text-blue-600">340</div>
                                  <div className="text-sm text-gray-600">Calories</div>
                                </div>
                              </div>
                            </div>
                          )}

                          {selectedProject.id === "food-delivery" && (
                            <div className="p-6">
                              <h1 className="text-2xl font-bold text-gray-800 mb-6">Restaurants Near You</h1>

                              <div className="space-y-4">
                                {[
                                  { name: "Pizza Palace", cuisine: "Italian", rating: "4.5", time: "25-35 min" },
                                  { name: "Burger Barn", cuisine: "American", rating: "4.2", time: "20-30 min" },
                                  { name: "Sushi Spot", cuisine: "Japanese", rating: "4.8", time: "30-40 min" },
                                ].map((restaurant, index) => (
                                  <div key={index} className="bg-gray-100 p-4 rounded-lg">
                                    <div className="font-bold text-gray-800">{restaurant.name}</div>
                                    <div className="text-sm text-gray-600 mt-1">{restaurant.cuisine}</div>
                                    <div className="text-xs text-gray-500 mt-2">
                                      ⭐ {restaurant.rating} • {restaurant.time}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Preview Controls */}
                    <div className="absolute -right-16 top-1/2 transform -translate-y-1/2 space-y-2">
                      <Button size="sm" variant="outline" className="w-12 h-12 p-0" title="Refresh">
                        <Play className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline" className="w-12 h-12 p-0" title="Open on Device">
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Preview Status */}
                <div className="p-3 border-t border-border bg-muted text-sm text-muted-foreground">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>Live preview active</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span>Last updated: {isRunning ? "Now" : "2m ago"}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Console Toggle Button - Floating at bottom */}
        {!showTerminal && (
          <div className="border-t border-border bg-muted p-2 flex justify-center">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setShowTerminal(true)}
              className="flex items-center space-x-2"
            >
              <Terminal className="w-4 h-4" />
              <span>Console</span>
              <ChevronUp className="w-3 h-3" />
            </Button>
          </div>
        )}

        {/* Terminal - Collapsible */}
        {showTerminal && (
          <div className="h-48 border-t bg-black text-green-400 font-mono text-sm flex-shrink-0 overflow-hidden">
            <div className="flex items-center justify-between p-2 border-b border-gray-700">
              <div className="flex items-center space-x-2">
                <Terminal className="w-4 h-4" />
                <span>Terminal - {selectedProject.name}</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="flex items-center space-x-2 text-xs">
                  <Github className="w-3 h-3" />
                  <span className="text-gray-400">{selectedProject.github.repo}</span>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setShowTerminal(false)}
                  className="h-6 w-6 p-0 text-gray-400 hover:text-white"
                >
                  <ChevronDown className="w-3 h-3" />
                </Button>
              </div>
            </div>
            <div className="p-4">
              <div>$ cd {selectedProject.name.toLowerCase().replace(/\s+/g, "-")}</div>
              <div>$ git status</div>
              <div className="text-gray-400">On branch {selectedProject.github.branch}</div>
              <div className="text-gray-400">
                Your branch is up to date with 'origin/{selectedProject.github.branch}'.
              </div>
              <div className="text-gray-400">nothing to commit, working tree clean</div>
              <div>$ npm start</div>
              <div className="text-gray-400">Starting development server for {selectedProject.name}...</div>
              {isRunning && (
                <>
                  <div className="text-green-400">✓ Metro bundler started</div>
                  <div className="text-green-400">✓ App running on http://localhost:8081</div>
                  <div className="text-blue-400">📱 Scan QR code to open on device</div>
                  <div className="text-gray-400">💾 Changes auto-synced to GitHub</div>
                </>
              )}
              {isGenerating && (
                <>
                  <div className="text-yellow-400">🤖 AI Assistant is modifying code...</div>
                  <div className="text-gray-400">⚡ Applying changes to {selectedProject.files[activeFile]?.name}</div>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
