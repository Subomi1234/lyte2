"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Save, Copy, Download, Upload, RotateCcw, Brain, MessageSquare, Zap, Settings } from "lucide-react"

const defaultSystemPrompt = `You are an expert AI assistant for WorkflowAI, a professional app development platform. Your role is to help users create high-quality mobile applications efficiently.

Core Principles:
- Always prioritize user experience and accessibility
- Provide clear, actionable guidance
- Ask clarifying questions when requirements are unclear
- Suggest best practices and industry standards
- Be proactive in identifying potential issues

Communication Style:
- Professional but friendly
- Concise yet thorough
- Use examples when helpful
- Acknowledge limitations honestly`

const behaviorPresets = [
  {
    id: "professional",
    name: "Professional Consultant",
    description: "Formal, detailed, enterprise-focused approach",
    systemPrompt: `You are a senior technical consultant specializing in enterprise mobile app development. You provide detailed, professional guidance with a focus on scalability, security, and best practices. Always consider business requirements and provide comprehensive solutions with clear reasoning.`,
    personality: {
      formality: 80,
      verbosity: 70,
      creativity: 40,
      caution: 90,
    },
  },
  {
    id: "creative",
    name: "Creative Partner",
    description: "Innovative, experimental, design-focused approach",
    systemPrompt: `You are a creative design partner who loves pushing boundaries and exploring innovative solutions. You encourage experimentation, suggest cutting-edge design patterns, and help users create unique, memorable experiences. You're enthusiastic about new trends and technologies.`,
    personality: {
      formality: 30,
      verbosity: 60,
      creativity: 90,
      caution: 30,
    },
  },
  {
    id: "mentor",
    name: "Learning Mentor",
    description: "Educational, patient, teaching-focused approach",
    systemPrompt: `You are a patient mentor who loves teaching and helping others learn. You explain concepts clearly, provide educational context, and encourage learning through hands-on practice. You break down complex topics into digestible steps and celebrate progress.`,
    personality: {
      formality: 50,
      verbosity: 80,
      creativity: 60,
      caution: 60,
    },
  },
  {
    id: "efficiency",
    name: "Efficiency Expert",
    description: "Fast, direct, results-focused approach",
    systemPrompt: `You are an efficiency expert focused on getting things done quickly and effectively. You provide direct, actionable advice with minimal fluff. You prioritize speed and practicality, suggesting the most efficient path to achieve goals while maintaining quality.`,
    personality: {
      formality: 60,
      verbosity: 30,
      creativity: 50,
      caution: 50,
    },
  },
]

const contextualBehaviors = [
  {
    id: "code-review",
    name: "Code Review",
    description: "How AI behaves when reviewing or modifying code",
    enabled: true,
    prompt:
      "When reviewing code, focus on performance, security, and maintainability. Always explain your suggestions and provide examples.",
  },
  {
    id: "design-feedback",
    name: "Design Feedback",
    description: "How AI provides design critiques and suggestions",
    enabled: true,
    prompt:
      "When giving design feedback, consider user experience, accessibility, and brand consistency. Be constructive and offer specific improvements.",
  },
  {
    id: "client-communication",
    name: "Client Communication",
    description: "How AI helps with client-facing communications",
    enabled: false,
    prompt:
      "When helping with client communication, use professional language, focus on business value, and avoid technical jargon unless necessary.",
  },
  {
    id: "problem-solving",
    name: "Problem Solving",
    description: "How AI approaches technical challenges",
    enabled: true,
    prompt:
      "When solving problems, break them down systematically, consider multiple approaches, and explain trade-offs clearly.",
  },
]

export function AIPreferences() {
  const [systemPrompt, setSystemPrompt] = useState(defaultSystemPrompt)
  const [selectedPreset, setSelectedPreset] = useState("")
  const [personality, setPersonality] = useState({
    formality: 60,
    verbosity: 60,
    creativity: 60,
    caution: 70,
  })
  const [behaviors, setBehaviors] = useState(contextualBehaviors)
  const [customInstructions, setCustomInstructions] = useState("")

  const applyPreset = (presetId: string) => {
    const preset = behaviorPresets.find((p) => p.id === presetId)
    if (preset) {
      setSystemPrompt(preset.systemPrompt)
      setPersonality(preset.personality)
      setSelectedPreset(presetId)
    }
  }

  const resetToDefault = () => {
    setSystemPrompt(defaultSystemPrompt)
    setPersonality({
      formality: 60,
      verbosity: 60,
      creativity: 60,
      caution: 70,
    })
    setSelectedPreset("")
  }

  const toggleBehavior = (id: string) => {
    setBehaviors((prev) =>
      prev.map((behavior) => (behavior.id === id ? { ...behavior, enabled: !behavior.enabled } : behavior)),
    )
  }

  const updateBehaviorPrompt = (id: string, prompt: string) => {
    setBehaviors((prev) => prev.map((behavior) => (behavior.id === id ? { ...behavior, prompt } : behavior)))
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">AI System Configuration</h1>
            <p className="text-sm text-gray-600 mt-1">
              Customize how your AI assistant thinks, communicates, and behaves
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" onClick={resetToDefault}>
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset to Default
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Save className="w-4 h-4 mr-2" />
              Save Configuration
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6 max-w-6xl mx-auto space-y-6">
        {/* Quick Presets */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center text-lg font-semibold text-gray-900">
              <Zap className="w-5 h-5 mr-2 text-blue-600" />
              Personality Presets
            </CardTitle>
            <p className="text-sm text-gray-600">Quick configurations for different working styles</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {behaviorPresets.map((preset) => (
                <Card
                  key={preset.id}
                  className={`cursor-pointer transition-all hover:shadow-md border ${
                    selectedPreset === preset.id ? "ring-2 ring-blue-500 border-blue-200" : "border-gray-200"
                  }`}
                  onClick={() => applyPreset(preset.id)}
                >
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium">{preset.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-sm text-gray-600 mb-3">{preset.description}</p>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Formality:</span>
                        <span className="font-medium">{preset.personality.formality}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Creativity:</span>
                        <span className="font-medium">{preset.personality.creativity}%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="system-prompt" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="system-prompt" className="flex items-center">
              <Brain className="w-4 h-4 mr-2" />
              System Prompt
            </TabsTrigger>
            <TabsTrigger value="personality" className="flex items-center">
              <MessageSquare className="w-4 h-4 mr-2" />
              Personality
            </TabsTrigger>
            <TabsTrigger value="behaviors" className="flex items-center">
              <Settings className="w-4 h-4 mr-2" />
              Behaviors
            </TabsTrigger>
            <TabsTrigger value="advanced" className="flex items-center">
              <Zap className="w-4 h-4 mr-2" />
              Advanced
            </TabsTrigger>
          </TabsList>

          <TabsContent value="system-prompt" className="space-y-6">
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Core System Prompt</CardTitle>
                <p className="text-sm text-gray-600">
                  This is the fundamental instruction that defines how your AI assistant thinks and operates. It's the
                  foundation of all AI interactions.
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="system-prompt" className="text-sm font-medium text-gray-700">
                    System Instructions
                  </Label>
                  <Textarea
                    id="system-prompt"
                    value={systemPrompt}
                    onChange={(e) => setSystemPrompt(e.target.value)}
                    rows={12}
                    className="mt-1 font-mono text-sm"
                    placeholder="Define how your AI assistant should think, behave, and respond..."
                  />
                  <p className="text-xs text-gray-500 mt-2">
                    {systemPrompt.length} characters • This prompt is sent with every AI interaction
                  </p>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">💡 System Prompt Tips</h4>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• Define the AI's role and expertise clearly</li>
                    <li>• Set communication style and tone preferences</li>
                    <li>• Include your core principles and values</li>
                    <li>• Specify how to handle uncertainty or errors</li>
                    <li>• Add any domain-specific knowledge or constraints</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="personality" className="space-y-6">
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">AI Personality Traits</CardTitle>
                <p className="text-sm text-gray-600">
                  Fine-tune how your AI communicates and approaches different situations
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">
                      Formality Level: {personality.formality}%
                    </Label>
                    <Slider
                      value={[personality.formality]}
                      onValueChange={(value) => setPersonality((prev) => ({ ...prev, formality: value[0] }))}
                      max={100}
                      step={10}
                      className="mt-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      {personality.formality < 40
                        ? "Casual & friendly"
                        : personality.formality < 70
                          ? "Professional but approachable"
                          : "Formal & business-like"}
                    </p>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-700">
                      Response Length: {personality.verbosity}%
                    </Label>
                    <Slider
                      value={[personality.verbosity]}
                      onValueChange={(value) => setPersonality((prev) => ({ ...prev, verbosity: value[0] }))}
                      max={100}
                      step={10}
                      className="mt-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      {personality.verbosity < 40
                        ? "Concise & direct"
                        : personality.verbosity < 70
                          ? "Balanced explanations"
                          : "Detailed & thorough"}
                    </p>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-700">
                      Creativity Level: {personality.creativity}%
                    </Label>
                    <Slider
                      value={[personality.creativity]}
                      onValueChange={(value) => setPersonality((prev) => ({ ...prev, creativity: value[0] }))}
                      max={100}
                      step={10}
                      className="mt-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      {personality.creativity < 40
                        ? "Conservative & proven"
                        : personality.creativity < 70
                          ? "Balanced innovation"
                          : "Experimental & cutting-edge"}
                    </p>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-700">Caution Level: {personality.caution}%</Label>
                    <Slider
                      value={[personality.caution]}
                      onValueChange={(value) => setPersonality((prev) => ({ ...prev, caution: value[0] }))}
                      max={100}
                      step={10}
                      className="mt-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      {personality.caution < 40
                        ? "Bold & confident"
                        : personality.caution < 70
                          ? "Thoughtfully cautious"
                          : "Very careful & thorough"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="behaviors" className="space-y-6">
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Contextual Behaviors</CardTitle>
                <p className="text-sm text-gray-600">Define how AI should behave in specific situations and contexts</p>
              </CardHeader>
              <CardContent className="space-y-4">
                {behaviors.map((behavior) => (
                  <div key={behavior.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <Switch checked={behavior.enabled} onCheckedChange={() => toggleBehavior(behavior.id)} />
                        <div>
                          <h4 className="font-medium text-gray-900">{behavior.name}</h4>
                          <p className="text-sm text-gray-600">{behavior.description}</p>
                        </div>
                      </div>
                    </div>

                    {behavior.enabled && (
                      <div>
                        <Label className="text-sm font-medium text-gray-700">Behavior Instructions</Label>
                        <Textarea
                          value={behavior.prompt}
                          onChange={(e) => updateBehaviorPrompt(behavior.id, e.target.value)}
                          rows={3}
                          className="mt-1 text-sm"
                          placeholder="Define how AI should behave in this context..."
                        />
                      </div>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-6">
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Advanced Instructions</CardTitle>
                <p className="text-sm text-gray-600">
                  Additional custom instructions and constraints for specialized use cases
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="custom-instructions" className="text-sm font-medium text-gray-700">
                    Custom Instructions
                  </Label>
                  <Textarea
                    id="custom-instructions"
                    value={customInstructions}
                    onChange={(e) => setCustomInstructions(e.target.value)}
                    rows={6}
                    className="mt-1"
                    placeholder="Add any additional instructions, constraints, or specialized knowledge..."
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Response Format</Label>
                    <Select defaultValue="adaptive">
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="adaptive">Adaptive (context-aware)</SelectItem>
                        <SelectItem value="structured">Always structured</SelectItem>
                        <SelectItem value="conversational">Always conversational</SelectItem>
                        <SelectItem value="bullet-points">Prefer bullet points</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-700">Error Handling</Label>
                    <Select defaultValue="explain">
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="explain">Explain limitations</SelectItem>
                        <SelectItem value="suggest">Suggest alternatives</SelectItem>
                        <SelectItem value="ask">Ask for clarification</SelectItem>
                        <SelectItem value="research">Offer to research</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Export/Import */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Configuration Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-2">
                  <Button variant="outline" className="flex-1 bg-transparent">
                    <Download className="w-4 h-4 mr-2" />
                    Export Configuration
                  </Button>
                  <Button variant="outline" className="flex-1 bg-transparent">
                    <Upload className="w-4 h-4 mr-2" />
                    Import Configuration
                  </Button>
                  <Button variant="outline">
                    <Copy className="w-4 h-4 mr-2" />
                    Copy System Prompt
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Live Preview */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Configuration Preview</CardTitle>
            <p className="text-sm text-gray-600">See how your AI will behave with current settings</p>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="space-y-3">
                <div>
                  <span className="text-sm font-medium text-gray-700">Personality:</span>
                  <div className="flex space-x-4 mt-1 text-sm text-gray-600">
                    <span>Formality: {personality.formality}%</span>
                    <span>Verbosity: {personality.verbosity}%</span>
                    <span>Creativity: {personality.creativity}%</span>
                    <span>Caution: {personality.caution}%</span>
                  </div>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-700">Active Behaviors:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {behaviors
                      .filter((b) => b.enabled)
                      .map((behavior) => (
                        <Badge key={behavior.id} variant="secondary" className="text-xs">
                          {behavior.name}
                        </Badge>
                      ))}
                  </div>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-700">System Prompt Length:</span>
                  <span className="text-sm text-gray-600 ml-2">{systemPrompt.length} characters</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
