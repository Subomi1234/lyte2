"use client"

import { useState } from "react"
import { MobilePreview } from "./mobile-preview"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, History, Undo, Eye, Wand2, Clock } from "lucide-react"

interface DesignChange {
  id: string
  prompt: string
  timestamp: string
  description: string
  screensBefore: any[]
  screensAfter: any[]
}

interface DesignWorkspaceProps {
  screens: any[]
  currentScreen: number
  onScreenChange: (index: number) => void
  onAddComment: (screenId: string, x: number, y: number, text: string) => void
  onScreensUpdate: (screens: any[]) => void
}

export function DesignWorkspace({
  screens,
  currentScreen,
  onScreenChange,
  onAddComment,
  onScreensUpdate,
}: DesignWorkspaceProps) {
  const [prompt, setPrompt] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  const [designHistory, setDesignHistory] = useState<DesignChange[]>([
    {
      id: "1",
      prompt: "Make the header bigger and add a search bar",
      timestamp: "2 hours ago",
      description: "Increased header height by 20px, added search functionality",
      screensBefore: screens,
      screensAfter: screens,
    },
    {
      id: "2",
      prompt: "Change the color scheme to be more modern",
      timestamp: "1 hour ago",
      description: "Updated primary colors to purple gradient, modernized buttons",
      screensBefore: screens,
      screensAfter: screens,
    },
  ])

  const handlePromptSubmit = async () => {
    if (!prompt.trim()) return

    setIsGenerating(true)

    // Simulate AI processing
    setTimeout(() => {
      const newChange: DesignChange = {
        id: Date.now().toString(),
        prompt: prompt,
        timestamp: "Just now",
        description: "Applied requested changes to design",
        screensBefore: screens,
        screensAfter: screens, // In real implementation, this would be the updated screens
      }

      setDesignHistory((prev) => [newChange, ...prev])
      setPrompt("")
      setIsGenerating(false)
    }, 2000)
  }

  const revertToVersion = (change: DesignChange) => {
    onScreensUpdate(change.screensBefore)
  }

  return (
    <div className="flex h-full">
      {/* Main Design Area */}
      <div className="flex-1 flex flex-col">
        <div className="flex justify-center flex-1 p-6">
          <MobilePreview
            screens={screens}
            currentScreen={currentScreen}
            onScreenChange={onScreenChange}
            onAddComment={onAddComment}
          />
        </div>

        {/* Prompt Section */}
        <div className="border-t bg-gray-50 p-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center space-x-3">
              <div className="flex-1 relative">
                <Input
                  placeholder="Describe the changes you want to make... (e.g., 'Make the buttons larger and change them to blue')"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      handlePromptSubmit()
                    }
                  }}
                  disabled={isGenerating}
                  className="pr-12"
                />
                <Button
                  size="sm"
                  onClick={handlePromptSubmit}
                  disabled={!prompt.trim() || isGenerating}
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8"
                >
                  {isGenerating ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                </Button>
              </div>
              <Button
                variant="outline"
                onClick={() => setShowHistory(!showHistory)}
                className="flex items-center space-x-2"
              >
                <History className="w-4 h-4" />
                <span>History</span>
                {designHistory.length > 0 && (
                  <Badge variant="secondary" className="text-xs">
                    {designHistory.length}
                  </Badge>
                )}
              </Button>
            </div>

            {isGenerating && (
              <div className="mt-3 flex items-center space-x-2 text-sm text-gray-600">
                <Wand2 className="w-4 h-4 animate-pulse" />
                <span>AI is applying your changes...</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* History Sidebar */}
      {showHistory && (
        <div className="w-80 border-l bg-white">
          <div className="p-4 border-b">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Design History</h3>
              <Button size="sm" variant="ghost" onClick={() => setShowHistory(false)}>
                ×
              </Button>
            </div>
            <p className="text-sm text-gray-600 mt-1">Track and revert design changes</p>
          </div>

          <ScrollArea className="h-[calc(100vh-120px)]">
            <div className="p-4 space-y-4">
              {designHistory.map((change, index) => (
                <Card key={change.id} className="relative">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <Badge variant={index === 0 ? "default" : "outline"} className="text-xs">
                            {index === 0 ? "Current" : `Version ${designHistory.length - index}`}
                          </Badge>
                          <span className="text-xs text-gray-500 flex items-center">
                            <Clock className="w-3 h-3 mr-1" />
                            {change.timestamp}
                          </span>
                        </div>
                        <p className="text-sm font-medium mb-1">"{change.prompt}"</p>
                        <p className="text-xs text-gray-600">{change.description}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex space-x-2">
                      {index > 0 && (
                        <Button size="sm" variant="outline" onClick={() => revertToVersion(change)} className="flex-1">
                          <Undo className="w-3 h-3 mr-1" />
                          Revert
                        </Button>
                      )}
                      <Button size="sm" variant="ghost" className="flex-1">
                        <Eye className="w-3 h-3 mr-1" />
                        Preview
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {designHistory.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <History className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No design changes yet</p>
                  <p className="text-xs">Use prompts to modify your design</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </div>
      )}
    </div>
  )
}
