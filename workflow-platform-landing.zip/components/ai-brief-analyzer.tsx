"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Upload, FileText, Zap, CheckCircle, AlertTriangle, Target, ArrowRight } from "lucide-react"

interface BriefAnalysis {
  completeness: number
  missingItems: Array<{
    category: string
    items: string[]
    priority: "high" | "medium" | "low"
  }>
  suggestions: Array<{
    type: "technical" | "business" | "user" | "timeline"
    title: string
    description: string
    action: string
  }>
  risks: Array<{
    category: string
    risk: string
    mitigation: string
    severity: "high" | "medium" | "low"
  }>
}

interface AIBriefAnalyzerProps {
  onAnalysisComplete: (brief: string) => void
}

export function AIBriefAnalyzer({ onAnalysisComplete }: AIBriefAnalyzerProps) {
  const [brief, setBrief] = useState("")
  const [analysis, setAnalysis] = useState<BriefAnalysis | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisStep, setAnalysisStep] = useState("")

  const analyzeBrief = async () => {
    if (brief.length < 50) return

    setIsAnalyzing(true)

    // Simulate AI analysis with steps
    const steps = [
      "Analyzing project scope...",
      "Identifying technical requirements...",
      "Evaluating business objectives...",
      "Assessing user requirements...",
      "Calculating risk factors...",
      "Generating recommendations...",
    ]

    for (let i = 0; i < steps.length; i++) {
      setAnalysisStep(steps[i])
      await new Promise((resolve) => setTimeout(resolve, 800))
    }

    // Generate comprehensive analysis
    const mockAnalysis: BriefAnalysis = {
      completeness: 72,
      missingItems: [
        {
          category: "Technical Requirements",
          items: [
            "Specific performance benchmarks (response times, throughput)",
            "Security compliance requirements (GDPR, PCI DSS)",
            "Integration specifications with existing systems",
            "Database schema and data migration requirements",
          ],
          priority: "high",
        },
        {
          category: "User Experience",
          items: [
            "User personas and journey mapping",
            "Accessibility requirements (WCAG compliance)",
            "Multi-language support specifications",
            "Offline functionality requirements",
          ],
          priority: "medium",
        },
        {
          category: "Business Requirements",
          items: [
            "Revenue model and monetization strategy",
            "Success metrics and KPIs",
            "Launch timeline and milestone breakdown",
            "Marketing and growth strategy",
          ],
          priority: "medium",
        },
      ],
      suggestions: [
        {
          type: "technical",
          title: "Define API Rate Limiting",
          description: "Specify rate limiting requirements to prevent abuse and ensure system stability",
          action: "Add rate limiting specifications (e.g., 1000 requests/minute per user)",
        },
        {
          type: "business",
          title: "Clarify Success Metrics",
          description: "Define measurable KPIs to track project success",
          action: "Add specific metrics like user acquisition, retention rates, revenue targets",
        },
        {
          type: "user",
          title: "Mobile-First Design",
          description: "Ensure mobile experience is prioritized given the target audience",
          action: "Specify mobile-first design requirements and responsive breakpoints",
        },
        {
          type: "timeline",
          title: "Phased Launch Strategy",
          description: "Consider a phased approach to minimize risk and gather feedback",
          action: "Define MVP features and subsequent release phases",
        },
      ],
      risks: [
        {
          category: "Technical",
          risk: "Scalability bottlenecks with projected user growth",
          mitigation: "Implement auto-scaling and load balancing from the start",
          severity: "high",
        },
        {
          category: "Business",
          risk: "Undefined revenue model may impact long-term sustainability",
          mitigation: "Define clear monetization strategy and pricing model",
          severity: "medium",
        },
        {
          category: "User",
          risk: "Complex user flow may lead to high abandonment rates",
          mitigation: "Simplify user journey and implement progressive disclosure",
          severity: "medium",
        },
      ],
    }

    setAnalysis(mockAnalysis)
    setIsAnalyzing(false)
    setAnalysisStep("")
  }

  const proceedToArchitecture = () => {
    onAnalysisComplete(brief)
  }

  useEffect(() => {
    if (brief.length > 50) {
      analyzeBrief()
    }
  }, [brief])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <h1 className="text-2xl font-semibold text-gray-900">Project Brief</h1>
        <p className="text-sm text-gray-600 mt-1">
          Upload or create your project brief to get AI-powered analysis and recommendations
        </p>
      </div>

      <div className="p-6 space-y-6">
        {/* Brief Input Section */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Project Brief Input</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-4">
              <Button variant="outline" className="flex items-center bg-transparent">
                <Upload className="w-4 h-4 mr-2" />
                Upload Document
              </Button>
              <Button variant="outline" className="flex items-center bg-transparent">
                <FileText className="w-4 h-4 mr-2" />
                Use Template
              </Button>
            </div>
            <Textarea
              value={brief}
              onChange={(e) => setBrief(e.target.value)}
              placeholder="Describe your project in detail. Include business objectives, target audience, key features, technical requirements, timeline, and any specific constraints or preferences..."
              className="min-h-[200px]"
            />
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-500">
                {brief.length} characters •{" "}
                {brief.length > 50
                  ? "AI analysis will begin automatically"
                  : "Enter at least 50 characters for analysis"}
              </p>
              {brief.length > 50 && !analysis && !isAnalyzing && (
                <Button onClick={analyzeBrief} className="bg-blue-600 hover:bg-blue-700">
                  <Zap className="w-4 h-4 mr-2" />
                  Analyze Brief
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Analysis Loading */}
        {isAnalyzing && (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 mx-auto mb-6 relative">
                <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Analyzing Your Brief</h3>
              <p className="text-gray-600 mb-4">{analysisStep}</p>
              <Progress value={((6 - (analysisStep ? 6 : 0)) / 6) * 100} className="w-64 mx-auto" />
            </CardContent>
          </Card>
        )}

        {/* Analysis Results */}
        {analysis && !isAnalyzing && (
          <>
            {/* Completeness Score */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Brief Analysis Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-3xl font-bold text-blue-600">{analysis.completeness}%</div>
                    <p className="text-sm text-gray-600">Completeness Score</p>
                  </div>
                  <Button onClick={proceedToArchitecture} className="bg-green-600 hover:bg-green-700">
                    <ArrowRight className="w-4 h-4 mr-2" />
                    Generate Architecture
                  </Button>
                </div>
                <Progress value={analysis.completeness} className="mb-6" />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{analysis.suggestions.length}</div>
                    <p className="text-sm text-gray-600">AI Suggestions</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-amber-600">
                      {analysis.missingItems.reduce((acc, item) => acc + item.items.length, 0)}
                    </div>
                    <p className="text-sm text-gray-600">Missing Items</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-red-600">{analysis.risks.length}</div>
                    <p className="text-sm text-gray-600">Risk Factors</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Missing Items */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Missing Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analysis.missingItems.map((category, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium text-gray-900">{category.category}</h4>
                        <Badge
                          variant={
                            category.priority === "high"
                              ? "destructive"
                              : category.priority === "medium"
                                ? "default"
                                : "secondary"
                          }
                        >
                          {category.priority} priority
                        </Badge>
                      </div>
                      <ul className="space-y-2">
                        {category.items.map((item, idx) => (
                          <li key={idx} className="flex items-start text-sm">
                            <AlertTriangle className="w-4 h-4 text-amber-500 mr-2 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* AI Suggestions */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">AI Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {analysis.suggestions.map((suggestion, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center mb-2">
                        <Badge variant="outline" className="mr-2">
                          {suggestion.type}
                        </Badge>
                        <h4 className="font-medium text-gray-900">{suggestion.title}</h4>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{suggestion.description}</p>
                      <div className="flex items-center text-sm">
                        <Target className="w-4 h-4 text-blue-500 mr-2" />
                        <span className="text-blue-700">{suggestion.action}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Risk Assessment */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Risk Assessment</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analysis.risks.map((risk, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium text-gray-900">{risk.category} Risk</h4>
                        <Badge
                          variant={
                            risk.severity === "high"
                              ? "destructive"
                              : risk.severity === "medium"
                                ? "default"
                                : "secondary"
                          }
                        >
                          {risk.severity} severity
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-700 mb-2">{risk.risk}</p>
                      <div className="flex items-start text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-green-700">{risk.mitigation}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Next Steps */}
            <Card className="border-0 shadow-sm bg-blue-50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-blue-900 mb-2">Analysis Complete!</h3>
                    <p className="text-blue-700">
                      Review the suggestions and proceed to generate the system architecture.
                    </p>
                  </div>
                  <Button onClick={proceedToArchitecture} size="lg" className="bg-blue-600 hover:bg-blue-700">
                    <ArrowRight className="w-5 h-5 mr-2" />
                    Generate Architecture
                  </Button>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  )
}
