"use client"

import type React from "react"

import { useState } from "react"
import { Smartphone, MessageSquare, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface Comment {
  id: string
  x: number
  y: number
  text: string
  author: string
  timestamp: string
}

interface MobilePreviewProps {
  screens: Array<{
    id: string
    name: string
    image: string
    comments: Comment[]
  }>
  currentScreen: number
  onScreenChange: (index: number) => void
  onAddComment: (screenId: string, x: number, y: number, text: string) => void
  isReviewMode?: boolean
}

export function MobilePreview({
  screens,
  currentScreen,
  onScreenChange,
  onAddComment,
  isReviewMode = false,
}: MobilePreviewProps) {
  const [showComments, setShowComments] = useState(true)
  const [isAddingComment, setIsAddingComment] = useState(false)
  const [pendingComment, setPendingComment] = useState<{ x: number; y: number } | null>(null)

  const handleScreenClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isReviewMode || !isAddingComment) return

    const rect = e.currentTarget.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100

    setPendingComment({ x, y })
  }

  const submitComment = (text: string) => {
    if (pendingComment && screens[currentScreen]) {
      onAddComment(screens[currentScreen].id, pendingComment.x, pendingComment.y, text)
      setPendingComment(null)
      setIsAddingComment(false)
    }
  }

  const currentScreenData = screens[currentScreen]

  return (
    <div className="flex flex-col items-center space-y-4">
      {/* Mobile Device Frame */}
      <div className="relative">
        <div className="w-80 h-[640px] bg-gray-900 rounded-[3rem] p-4 shadow-2xl">
          <div className="w-full h-full bg-white rounded-[2rem] overflow-hidden relative">
            {/* Screen Content */}
            <div
              className="w-full h-full bg-gray-50 cursor-pointer relative"
              onClick={handleScreenClick}
              style={{
                backgroundImage: currentScreenData?.image ? `url(${currentScreenData.image})` : undefined,
                backgroundSize: "cover",
                backgroundPosition: "center",
              }}
            >
              {!currentScreenData?.image && (
                <div className="flex items-center justify-center h-full text-gray-400">
                  <div className="text-center">
                    <Smartphone className="w-16 h-16 mx-auto mb-4" />
                    <p>Screen Preview</p>
                  </div>
                </div>
              )}

              {/* Comments Overlay */}
              {showComments &&
                currentScreenData?.comments.map((comment) => (
                  <div
                    key={comment.id}
                    className="absolute w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-bold cursor-pointer hover:scale-110 transition-transform"
                    style={{
                      left: `${comment.x}%`,
                      top: `${comment.y}%`,
                      transform: "translate(-50%, -50%)",
                    }}
                    title={comment.text}
                  >
                    <MessageSquare className="w-3 h-3" />
                  </div>
                ))}

              {/* Pending Comment */}
              {pendingComment && (
                <div
                  className="absolute w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold animate-pulse"
                  style={{
                    left: `${pendingComment.x}%`,
                    top: `${pendingComment.y}%`,
                    transform: "translate(-50%, -50%)",
                  }}
                >
                  <MessageSquare className="w-3 h-3" />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Device Controls */}
        <div className="absolute -right-16 top-1/2 transform -translate-y-1/2 space-y-2">
          <Button size="sm" variant="outline" onClick={() => setShowComments(!showComments)} className="w-12 h-12 p-0">
            <Eye className="w-4 h-4" />
          </Button>
          {isReviewMode && (
            <Button
              size="sm"
              variant={isAddingComment ? "default" : "outline"}
              onClick={() => setIsAddingComment(!isAddingComment)}
              className="w-12 h-12 p-0"
            >
              <MessageSquare className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      {/* Screen Navigation */}
      <div className="flex space-x-2 overflow-x-auto max-w-80">
        {screens.map((screen, index) => (
          <Button
            key={screen.id}
            variant={index === currentScreen ? "default" : "outline"}
            size="sm"
            onClick={() => onScreenChange(index)}
            className="flex-shrink-0"
          >
            {screen.name}
            {screen.comments.length > 0 && (
              <Badge variant="destructive" className="ml-2 text-xs">
                {screen.comments.length}
              </Badge>
            )}
          </Button>
        ))}
      </div>

      {/* Comment Input */}
      {pendingComment && (
        <Card className="w-80">
          <CardContent className="p-4">
            <textarea
              placeholder="Add your comment..."
              className="w-full p-2 border rounded resize-none"
              rows={3}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  submitComment(e.currentTarget.value)
                  e.currentTarget.value = ""
                }
              }}
            />
            <div className="flex justify-end space-x-2 mt-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setPendingComment(null)
                  setIsAddingComment(false)
                }}
              >
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={() => {
                  const textarea = document.querySelector("textarea") as HTMLTextAreaElement
                  if (textarea?.value.trim()) {
                    submitComment(textarea.value)
                    textarea.value = ""
                  }
                }}
              >
                Add Comment
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
